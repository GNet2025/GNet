clear all;
clc;
close all;

% Updated .mat file names
load('HDCGNet_FashionMNIST.mat')
load('HoloGN_FashionMNIST.mat')
load('LaplaceHDC_FashionMNIST.mat')
load('OnlineHD_FashionMNIST.mat')
load('RFFHDC_FashionMNIST.mat')
load('VanillaHDC_FashionMNIST.mat')

% x-axis: percentage of flipped bits
x = 0.0:0.05:0.5;

% Mean accuracy per method
m1 = mean(FashionMNIST_HDCGNet, 2);
m2 = mean(HoloGN_FashionMNIST, 2);
m3 = mean(LaplaceHDC_FashionMNIST, 2);
m4 = mean(FashionMNIST_OnlineHD, 2);
m5 = mean(RFFHDC_FashionMNIST, 2);
m6 = mean(VanillaHDC_FashionMNIST, 2);

% Standard deviations
s1 = std(FashionMNIST_HDCGNet, 0, 2);
s2 = std(HoloGN_FashionMNIST, 0, 2);
s3 = std(LaplaceHDC_FashionMNIST, 0, 2);
s4 = std(FashionMNIST_OnlineHD, 0, 2);
s5 = std(RFFHDC_FashionMNIST, 0, 2);
s6 = std(VanillaHDC_FashionMNIST, 0, 2);

% Confidence interval range
gamma = 1;
m1u = m1 + gamma*s1;  m1l = m1 - gamma*s1;
m2u = m2 + gamma*s2;  m2l = m2 - gamma*s2;
m3u = m3 + gamma*s3;  m3l = m3 - gamma*s3;
m4u = m4 + gamma*s4;  m4l = m4 - gamma*s4;
m5u = m5 + gamma*s5;  m5l = m5 - gamma*s5;
m6u = m6 + gamma*s6;  m6l = m6 - gamma*s6;

xconf = [x x(end:-1:1)];
yconf1 = [m1u' m1l(end:-1:1)'];
yconf2 = [m2u' m2l(end:-1:1)'];
yconf3 = [m3u' m3l(end:-1:1)'];
yconf4 = [m4u' m4l(end:-1:1)'];
yconf5 = [m5u' m5l(end:-1:1)'];
yconf6 = [m6u' m6l(end:-1:1)'];

% Create figure
figure1 = figure('position',[100 100 800 700]);
axes1 = axes('Parent',figure1,'Position',[0.088 0.11 0.86 0.84]);
hold(axes1,'on');

% Confidence patches
patch('Parent',axes1,'YData',yconf1,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.85 0.51 0.34],'EdgeColor','none');
patch('Parent',axes1,'YData',yconf2,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.6 0.30 0.11],'EdgeColor','none');
patch('Parent',axes1,'YData',yconf3,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.29 0.73 0.87],'EdgeColor','none');
patch('Parent',axes1,'YData',yconf4,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.28 0.83 0.37],'EdgeColor','none');
patch('Parent',axes1,'YData',yconf5,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.97 0.77 0.34],'EdgeColor','none');
patch('Parent',axes1,'YData',yconf6,'XData',xconf,'FaceAlpha',0.5,'FaceColor',[0.82 0.64 0.95],'EdgeColor','none');

% Accuracy curves
plot1 = plot(x,[m1,m2,m3,m4,m5,m6],'MarkerSize',9,'LineWidth',3,'Parent',axes1);
set(plot1(1),'DisplayName','HDC-GNet','Marker','o','Color',[0.85 0.29 0.051]);
set(plot1(2),'DisplayName','HoloGN','Marker','^','Color',[0.53 0.25 0.06]);
set(plot1(3),'DisplayName','Laplace-HDC','Marker','*','Color',[0.21 0.59 0.90]);
set(plot1(4),'DisplayName','OnlineHD','Marker','+','Color',[0.19 0.77 0.13]);
set(plot1(5),'DisplayName','RFF-HDC','Marker','square','Color',[0.91 0.53 0.063]);
set(plot1(6),'DisplayName','Classic HDC','Marker','pentagram','Color',[0.58 0.3 0.93]);

% Axes labels
ylabel('Accuracy (\%)','Interpreter','latex');
xlabel('Hyperdimension ($N$)','Interpreter','latex');
xlim([min(x),max(x)]);
box(axes1,'on');
hold(axes1,'off');

% Formatting
set(axes1,'FontSize',20,'XGrid','on','YGrid','on','YMinorTick','on');
legend1 = legend(plot1,{'HDC-GNet','HoloGN','LaplaceHDC','OnlineHD','RFF-HDC','Classic-HDC'});
set(legend1,'Position',[0.5929 0.1267 0.3498 0.1936],'FontSize',24,'NumColumns',2,'Interpreter','latex');
